package bank_stimulator;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class homescreen extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	static String acc="";
	static String name="";
	static String pass="";
	public static void main(String[] args) {
		if(args.length !=0)
			{acc=args[0];
			name=args[1];
			pass=args[2];
			}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					homescreen frame = new homescreen();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public homescreen() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 350);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnTransaction = new JButton("Transaction");
		btnTransaction.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				transaction ob1=new transaction();
				String arr[]={acc};
				ob1.main(arr);
	
				//transaction frame=new transaction();
				//frame.setVisible(true);
			}
		});
		
		JButton btnMiniStatement = new JButton("Mini Statement");
		btnMiniStatement.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				showtable ob=new showtable();
				String arr[]={acc,name};
					ob.main(arr);
				
				
				
			}
		});
		
		JButton btnChangePassword = new JButton("Change Password");
		btnChangePassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				change_password frame=new change_password(acc,name,"home",pass);
				frame.setVisible(true);
			}
		});
		
		JButton btnLogOut = new JButton("Log Out");
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				login frame=new login();
				frame.setVisible(true);

				frame.setLocationRelativeTo(null);
			}
		});
		
		JLabel lblWelcome = new JLabel("Welcome");
		lblWelcome.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		JLabel lblX = new JLabel("x");
		lblX.setText(name);
		lblX.setFont(new Font("Tahoma", Font.BOLD, 15));
		
		final JButton btnBalanceEnquiray = new JButton("Balance Enquiry");
		btnBalanceEnquiray.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				sqlacc ob=new sqlacc();
				
				JOptionPane.showMessageDialog(btnBalanceEnquiray, "Your Account Balance is :"+ob.Query(acc));
				
				
				
			}
		});
		
		JButton button = new JButton("<-Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				login frame=new login();
				frame.setVisible(true);
				frame.setLocationRelativeTo(null);
			}
		});
		
		final JButton btnDeleteAccount = new JButton("Delete Account");
		btnDeleteAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String passchck=JOptionPane.showInputDialog(btnDeleteAccount, "Enter your password:");
				//JOptionPane.showMessageDialog(btnDeleteAccount,"Enterd password:"+pass);
				if(passchck.equals(pass))
				{
					sqlquery ob1=new sqlquery();
					ob1.deleteAccount(acc);
					sqlacc ob=new sqlacc();
					ob.deleteAcctable(acc);
					//delete table
					JOptionPane.showMessageDialog(btnDeleteAccount,"Account Deleted Successfully..");
					dispose();
					login frame=new login();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				
				}
				else
						JOptionPane.showMessageDialog(btnDeleteAccount,"Sorry!! Incorrect Password");
			//	dispose();
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(63)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(btnChangePassword)
								.addComponent(btnTransaction)
								.addComponent(button)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(44)
							.addComponent(lblWelcome)
							.addGap(18)
							.addComponent(lblX)))
					.addPreferredGap(ComponentPlacement.RELATED, 80, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnMiniStatement)
						.addComponent(btnBalanceEnquiray))
					.addContainerGap(103, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap(393, Short.MAX_VALUE)
					.addComponent(btnLogOut)
					.addContainerGap())
				.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
					.addGap(170)
					.addComponent(btnDeleteAccount)
					.addContainerGap(215, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(30)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblWelcome)
						.addComponent(lblX))
					.addGap(33)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnTransaction)
						.addComponent(btnMiniStatement))
					.addGap(49)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnChangePassword)
						.addComponent(btnBalanceEnquiray))
					.addGap(32)
					.addComponent(btnDeleteAccount)
					.addPreferredGap(ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnLogOut)
						.addComponent(button))
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
	}
}
