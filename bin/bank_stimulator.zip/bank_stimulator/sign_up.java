package bank_stimulator;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JPasswordField;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JComboBox;

import java.awt.Font;

public class sign_up extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	
	public static void main(String[] args) {
		//login.visible();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					sign_up frame = new sign_up();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public sign_up() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 350);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblName = new JLabel("Name:");
		
		JLabel lblGender = new JLabel("Gender:");
		
		JLabel lblMobile = new JLabel("Mobile:");
		
		JLabel lblPassword = new JLabel("Password:");
		
		JLabel lblConfirmPassword = new JLabel("Confirm Password:");
		
		JLabel lblSequirityQuestion = new JLabel("Sequirity Question:");
		
		JLabel lblAnswer = new JLabel("Answer:");
		
		final JCheckBox chckbxIAgreTo = new JCheckBox("I agree to Terms And Condition Mention ");
		
		final JButton btnConfirm = new JButton("Confirm");
		
		JButton btnClear = new JButton("Clear");
		
	final JRadioButton rdbtnMale = new JRadioButton("Male");
		
		final JRadioButton rdbtnFemale = new JRadioButton("Female");
	ButtonGroup group=new ButtonGroup();
	group.add(rdbtnMale);
	group.add(rdbtnFemale);	
		final JComboBox comboBox = new JComboBox();
		comboBox.addItem("Your Native Place?");
		comboBox.addItem("Your Mother toungue?");
		comboBox.addItem("Your Mother's Native place?");
		comboBox.addItem("Which year is your favourite?");
		comboBox.addItem("Your Secret code?");
	//	JButton btnConfirm = new JButton("Confirm");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				/*dispose();
				sign_up frame=new sign_up();
				frame.setVisible(true);*/
				textField.setText("");
				textField_1.setText("");
				//textField_2.setText("");
				textField_3.setText("");
				textField_4.setText("");
				passwordField.setText("");
				passwordField_1.setText("");
			chckbxIAgreTo.setSelected(false);
				rdbtnMale.setSelected(false);
				rdbtnFemale.setSelected(false);
				}
				});
		
		
		btnConfirm.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent arg0) {
	
		
		 final String name=textField.getText().trim();
			final String pass=passwordField.getText();
			final String pass1=passwordField_1.getText();
			final String que=(String) comboBox.getSelectedItem();
			final String ans=textField_3.getText();
			final String mob=textField_1.getText().trim();
			final String ag=textField_4.getText().trim();
			String gen="";
			
		if(rdbtnMale.isSelected())
			{
			gen=rdbtnMale.getText();
			//rdbtnFemale.setSelected(false);
			}
		if(rdbtnFemale.isSelected())
		{
				gen=rdbtnFemale.getText();	
			//	rdbtnMale.setSelected(false);
		}
				if(pass.equals(pass1) && (mob.length()==10 || mob.length()==11) && name.length()!=0 &&ag.length()!=0&&que.length()!=0&&ans.length()!=0
					&& chckbxIAgreTo.isSelected()&&(rdbtnMale.isSelected()||rdbtnFemale.isSelected()))
			{
			sqlquery obnew=new sqlquery();
			String acc=obnew.genarateAcc();
			//textField.setText(acc);
			obnew.insert(acc,pass,name,gen,ag,que,ans,mob);
			obnew.createtable(acc);
				JOptionPane.showMessageDialog(btnConfirm, "Saved.Your Acc No is :'"+acc+"'.  Note it down for further use.");
			dispose();
			login frame=new login();
			frame.setVisible(true);
			frame.setLocationRelativeTo(null);
	}
			else
				JOptionPane.showMessageDialog(btnConfirm, "Your Data is Invalid . Enter data correctly And Completely!!!");
			
	}
});

	
		JButton btnbacktomenu = new JButton("<-Back");	
		btnbacktomenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();	
				login ob1=new login();
					String arr[]={""};
					ob1.main(arr);
		
			}
		});
	
	
	
		textField = new JTextField();
		textField.setColumns(10);
		
	//	final JRadioButton rdbtnMale = new JRadioButton("Male");
		
	//	final JRadioButton rdbtnFemale = new JRadioButton("Female");
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		
		passwordField = new JPasswordField();
		
		passwordField_1 = new JPasswordField();
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		
		JLabel lblAge = new JLabel("Age:");
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		
		JLabel lblansweIsCasesensativeplease = new JLabel("*Answe is Case_Sensative.Please do remember.");
		lblansweIsCasesensativeplease.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 9));
		
		JButton btnExit = new JButton("EXIT");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			dispose();
			}
		});
		
		JLabel lblDidtsOnly = new JLabel("(*10 digits only)");
		lblDidtsOnly.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 9));
		//lblansweIsCasesensativeplease.setMinimumSize();
	//	JComboBox comboBox = new JComboBox();
		
//
		
		  		
		

		
		
		
		
		
		
		
		//..........................................................................................................
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(103)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblName, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblGender)
								.addComponent(lblMobile)
								.addComponent(lblPassword)
								.addComponent(lblConfirmPassword))
							.addGap(23)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(rdbtnMale)
									.addGap(18)
									.addComponent(rdbtnFemale)
									.addGap(18)
									.addComponent(lblAge)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE))
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(passwordField_1, Alignment.LEADING)
										.addComponent(passwordField, Alignment.LEADING)
										.addComponent(textField_1, Alignment.LEADING))
									.addGap(14)
									.addComponent(lblDidtsOnly))))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblSequirityQuestion)
								.addComponent(lblAnswer))
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(comboBox, 0, 245, Short.MAX_VALUE)
								.addComponent(textField_3, GroupLayout.DEFAULT_SIZE, 245, Short.MAX_VALUE)
								.addComponent(lblansweIsCasesensativeplease)))
						.addComponent(chckbxIAgreTo)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(btnbacktomenu)
							.addGap(27)
							.addComponent(btnConfirm)
							.addGap(33)
							.addComponent(btnClear)
							.addPreferredGap(ComponentPlacement.RELATED, 59, Short.MAX_VALUE)
							.addComponent(btnExit)))
					.addGap(22))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblName)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblGender)
						.addComponent(rdbtnMale)
						.addComponent(rdbtnFemale)
						.addComponent(lblAge)
						.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblMobile)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblDidtsOnly))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPassword)
						.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblConfirmPassword)
						.addComponent(passwordField_1, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblSequirityQuestion)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(11)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAnswer)
						.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblansweIsCasesensativeplease, GroupLayout.PREFERRED_SIZE, 9, GroupLayout.PREFERRED_SIZE)
					.addGap(11)
					.addComponent(chckbxIAgreTo)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnClear)
						.addComponent(btnConfirm)
						.addComponent(btnExit)
						.addComponent(btnbacktomenu))
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
	}
}
